import java.util.Arrays;
import java.util.Scanner;

import files.WordReader;

/**
 * In this HW, we will be implementing the game Pick Your Letters, which is a game that involves 
 * re-arranging a group of cards in order to make up a word.
 * 
 * About the Game
 * This game needs two players and we will just play the user versus the computer. 
 * The user’s moves are decided by the user playing the game, by asking for input, and the computer’s 
 * moves are decided by the program.
 */
public class PickYourLetters {
	
	public static void main(String[] args) {
		
		PickYourLetters pyl = new PickYourLetters();
		pyl.run();
	}
	
	/**
	 * Launches and controls the game.
	 */
	public void run() {
		
		System.out.println("Welcome to the game!");
		
		//reads all words from file
		WordReader wr = new WordReader();
		String[] allWords = wr.readFromFile("words.txt");

		//create scanner for user input
		Scanner scanner = new Scanner(System.in);		

		//ask for a number as the length of the word
		//TODO Add your code here

		//create WordProcessor
		//filter allWords with a length equal to the given length
		//TODO Add your code here
		
		//create Cards
		//set up mainPile and discardPile
		//TODO Add your code here
	    
	    //shuffle main pile
		//TODO Add your code here
	    
	    //create computer player and human player
	    //deal cards to players and initialize discard pile
		//TODO Add your code here
	    
	    //set up a target word list for computer strategy
		//TODO Add your code here
	    
	    System.out.println("-----------------------------------------------");
	    
	    //run the game
	    while (true) {
	    	
	        //first check if mainPile is empty by calling checkCards() in Cards class
	    	//TODO Add your code here
	        
	        //computer's turn
	    	//TODO Add your code here
	        		    
		    //human's turn
	    	//TODO Add your code here
	    	
		    //check if game is over, and print out results
	    	//TODO Add your code here
	    }
	    
	    //close scanner
	    scanner.close();
	}
	
	/**
	 * Asks the user for the number of hand cards.
	 * Prompts again if the user input is not a valid integer, 
	 * or if the number is not between 3 - 10, inclusive.
	 * @param scanner for user input
	 * @return an integer indicating the number of hand cards
	 */
	public int askForLength(Scanner scanner) {
	    
		//TODO Add your code here
	}
	
	/**
	 * Checks if the game is over.
	 * @param humanHandCards human player's current letters in hand
	 * @param computerHandCards computer player's current letters in hand
	 * @param wordsWithSpecificLength an array containing all the words with a specific length
	 * @return true if computer or human wins the game or if there is a tie, otherwise, false
	 */
	public boolean checkGameOver(String[] humanHandCards, String[] computerHandCards, String[] wordsWithSpecificLength) {
	   
		//TODO Add your code here	
	}
}
