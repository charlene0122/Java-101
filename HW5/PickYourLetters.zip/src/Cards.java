import java.util.Random;

/**
 * Creates and manages a main pile of cards and a discard pile of cards.
 *
 */
public class Cards {

	/**
	 * Main pile of cards. 
	 */
	String[] mainPile;
	
	/**
	 * Discard pile of cards.
	 */
	String[] discardPile;
	
	/**
	 * Creates instance of Cards class.
	 */
	public Cards() {
		
	}
	
	/**
	 * Sets up main pile, which is an array containing the letters of the alphabet * length.
	 * @param length of the words
	 * @return main pile
	 */
	public String[] setUpMain(int length) {
	   
		//TODO Add your code here
	}
	
	/**
	 * Sets up discard pile, which is an empty array.
	 * @return discard pile
	 */
	public String[] setUpDiscard() {
		   
		//TODO Add your code here
	}
	
	/**
	 * Gets the main pile.
	 * @return main pile
	 */
	public String[] getMainPile() {
		
		//TODO Add your code here
	}
	
	/**
	 * Gets the discard pile.
	 * @return discard pile
	 */
	public String[] getDiscardPile() {
		
		//TODO Add your code here
	}
	
	/**
	 * Shuffles cards in the main pile.
	 */
	public void shuffleMainCards() {
		
		//TODO Add your code here
	}
	
	/**
	 * Shuffles cards in the discard pile.
	 */
	public void shuffleDiscardCards() {
		
		//TODO Add your code here
	}
	
	/**
	 * Deals two hands of length cards each to the given computer player 
	 * and to the given human player. Deals cards from the main pile.
	 * The computer is always the first person that gets dealt.
	 * Removes the card on top of the main pile and put it on the discard pile.
	 * @param computer computer player
	 * @param human human player
	 * @param length of the hand cards
	 */
	public void dealInitialCards(Computer computer, Human human, int length) {

		//TODO Add your code here
	}
	
	/**
	 * Checks whether the main pile is empty.
	 * If so, shuffles the discard pile and moves all the cards to the main pile.
	 * Then turns over the top card of the main pile to be the start of the new discard pile.
	 * Otherwise, does nothing.
	*/
	public void checkCards() {
	    
		//TODO Add your code here
	}
	
	/**
	 * Returns and removes the first card of the main pile.
	 * @return the first card of the main pile
	 */
	public String getFirstFromMainPileAndRemove() {
		
		//TODO Add your code here
	}
	
	/**
	 * Returns and removes the first card of the discard pile.
	 * @return the first card of the discard pile
	 */
	public String getFirstFromDiscardPileAndRemove() {
		
		//TODO Add your code here
	}
	
	/**
	 *  Adds given card to top of the discard pile.
	 * @param card to add to top of discard pile
	 */
	public void addToDiscardPile(String card) {
		
		//TODO Add your code here
	}
}
