package files;

/**
 * Filters all the words (in an array) based on a given length.
 *
 */
public class WordProcessor {

	/**
	 * Filters the words with a length equal to the given length.
	 * @param allWords array containing all the words
	 * @param length to filter words
	 * @return an array containing all the words with specific length
	 */
	public String[] filterWordList(String[] allWords, int length) {

		//TODO Add your code here
	}
}
