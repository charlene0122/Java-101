/**
 * Represents a computer player.
 *
 */
public class Computer {
	
	/**
	 * Computer player's hand.
	 */
	String[] handCards;
	
	/**
	 * Access to main pile and discard pile.
	 */
	Cards cards;
	
	/**
	 * Creates a computer player.
	 * Gives access to the main pile and discard pile via given instance of Cards class.
	 * @param cards for access to main pile and discard pile
	 */
	public Computer(Cards cards) {
		this.cards = cards;
	}
	
	/**
	 * Sets computer player's hand.
	 * @param handCards to set
	 */
	public void setHandCards(String[] handCards) {
		
		//TODO Add your code here
	}
	
	/**
	 * Gets computer player's hand.
	 * @return computer player's hand
	 */
	public String[] getHandCards() {
		
		//TODO Add your code here
	}

	/**
	 * Controls the game play for the computer.
	 * The computer first decides if the letter from the discard pile is useful, if so, 
	 * the computer will take the letter; otherwise, the computer will take the letter from 
	 * main pile and then decide if that's useful.
	 * 
	 * To decide if a given new letter is useful, the computer can put all the potential 
	 * words, which are the most similar words to the current word, in the target array.
	 * If replacing one letter in the current word with the new letter will increase the 
	 * similarity, then the computer decides the given new letter is useful.
	 * 
	 * @param targetArray containing all the most similar words to the current hand cards
	 * @return the newly narrowed down array
	 */
	public String[] play(String[] targetArray) {
	    
		//TODO Add your code here
	}
}