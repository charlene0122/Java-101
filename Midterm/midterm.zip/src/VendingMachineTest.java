

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class VendingMachineTest {

	@Test 
	void testAddItem() {
		
		//create inventory
		Item pretzels = new Item(29, "Pretzels", 0.60);
		Item chips = new Item(381, "Chips", 1.25);
		Item candy = new Item(328, "Candy", 2.85);
		Item[] itemInventory = { pretzels, chips, candy };

		//create vending machine
		VendingMachine v = new VendingMachine(itemInventory);
		
		
		//add new item that doesn't exist
		Item newItem = new Item(4, "Chocolate", 2.99);
		boolean added = v.addItem(newItem);
		
		//check that it was added
		assertTrue(added);
		
		//check new length of array
		assertEquals(4, v.getInventory().length);
		
		//check that item is in inventory
		assertNotEquals(null, v.selectItemByNumber(newItem.getID()));
		assertEquals(newItem.getID(), v.selectItemByNumber(newItem.getID()).getID());
		
		
		//add another new item that doesn't exist
		newItem = new Item(5, "Milky Way", 3.25);
		added = v.addItem(newItem);
				
		//check that it was added
		assertTrue(added);
				
		//check new length of array
		assertEquals(5, v.getInventory().length);
		
		//check that item is in inventory
		assertNotEquals(null, v.selectItemByNumber(newItem.getID()));
		assertEquals(newItem.getID(), v.selectItemByNumber(newItem.getID()).getID());
		
		
		//TODO Add 1 more test case here
		//Hint:
		//- Consider a test case for adding a new item that already exists 
		//in the inventory
		
	}
	
	@Test 
	void testRemoveItem() {
		
		//create inventory
		Item pretzels = new Item(29, "Pretzels", 0.60);
		Item chips = new Item(381, "Chips", 1.25);
		Item candy = new Item(328, "Candy", 2.85);
		Item[] itemInventory = { pretzels, chips, candy };

		//create vending machine
		VendingMachine v = new VendingMachine(itemInventory);
		
		
		//remove item that exists
		boolean removed = v.removeItem(381);
		
		//check that it was removed
		assertTrue(removed);
		
		//check new length of array
		assertEquals(2, v.getInventory().length);
		
		//check that item is no longer in inventory
		assertEquals(null, v.selectItemByNumber(381));
		
		
		//remove another item that exists
		removed = v.removeItem(29);
		
		//check that it was removed
		assertTrue(removed);
		
		//check new length of array
		assertEquals(1, v.getInventory().length);
		
		//check that item is no longer in inventory
		assertEquals(null, v.selectItemByNumber(29));
		
		
		//TODO Add 1 more test case here
		//Hint:
		//- Consider a test case for removing an item that doesn't exist 
		//in the inventory
		
	}
	
	@Test
	void testSelectItemByNumber() {
		
		//create inventory
		Item pretzels = new Item(29, "Pretzels", 0.60);
		Item chips = new Item(381, "Chips", 1.25);
		Item candy = new Item(328, "Candy", 2.85);
		Item[] itemInventory = { pretzels, chips, candy };

		//create vending machine
		VendingMachine v = new VendingMachine(itemInventory);
		
		
		//existing item 
		Item item = v.selectItemByNumber(381);
		assertEquals(381, item.getID());
		assertEquals("Chips", item.getName());
		
		
		//TODO Add 2 more test cases here
		//Hint:
		//- Consider a test case for selecting an item that exists
		//- Consider a test case for selecting an item that doesn't exist
		
	}
	
	@Test
	void testSelectItemByName() {
		
		//create inventory
		Item pretzels = new Item(29, "Pretzels", 0.60);
		Item chips = new Item(381, "Chips", 1.25);
		Item candy = new Item(328, "Candy", 2.85);
		Item[] itemInventory = { pretzels, chips, candy };

		//create vending machine
		VendingMachine v = new VendingMachine(itemInventory);
		
		
		//existing item 
		Item item = v.selectItemByName("Chips");
		assertEquals(381, item.getID());
		assertEquals("Chips", item.getName());
		
		
		//TODO Add 2 more test cases here
		//Hint:
		//- Consider a test case for selecting an item that exists
		//- Consider a test case for selecting an item that doesn't exist
		
	}
	
	
	@Test
	void testAttemptPurchase() {
		
		//create inventory
		Item pretzels = new Item(29, "Pretzels", 0.60);
		Item chips = new Item(381, "Chips", 1.25);
		Item candy = new Item(328, "Candy", 2.85);
		Item[] itemInventory = { pretzels, chips, candy };

		//create vending machine
		VendingMachine v = new VendingMachine(itemInventory);
				
		//create payment
		Payment myMoney = new Payment(2, 1, 1);
		
		
		//unsuccessful transaction
		//create transaction
		Transaction failedTransaction = v.attemptPurchase(328, myMoney);
		
		//get returned payment
		myMoney = failedTransaction.getPayment();
		
		//check isSuccessful value
		assertFalse(failedTransaction.getIsSuccessful());
		
		//check that returned payment has same value
		assertEquals(2.35, myMoney.calculateValue(), 0.000001);
		
		//check that returned item has same id
		assertEquals(328, failedTransaction.getItem().getID());
		
		
		//successful transaction
		//create transaction
		Transaction forChips = v.attemptPurchase(381, myMoney);
		
		//get returned payment
		myMoney = forChips.getPayment();
		
		//should be successful
		//check isSuccessful value
		assertTrue(forChips.getIsSuccessful());
				
		//check that returned payment has correct value of change
		assertEquals(1.10, myMoney.calculateValue(), 0.000001);
				
		//check that returned item has correct id
		assertEquals(381, forChips.getItem().getID());

		
		//TODO Add 1 more test case here
		//Hint:
		//- Consider a test case for another successful transaction

	}

}
