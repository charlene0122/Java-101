/**
 * Represents a sum of money.  Its fields track how many dollars ($1.00), 
 * quarters ($0.25), and dimes ($0.10) the Payment consists of.
 */
public class Payment {

	/**
	 * Numbers of dollars.
	 */
	int dollars;
	
	/**
	 * Numbers of quarters.
	 */
	int quarters;
	
	/**
	 * Number of dimes.
	 */
	int dimes;

	/**
	 * Creates a payment with given number of dollars, quarters, and dimes.
	 * @param numDollars number of dollars
	 * @param numQuarters number of quarters
	 * @param numDimes number of dimes
	 */
	public Payment(int numDollars, int numQuarters, int numDimes) {
		this.dollars = numDollars;
		this.quarters = numQuarters;
		this.dimes = numDimes;
	}

	/**
	 * Returns the value of this payment based on the number of dollars, quarters,
	 * and dimes. The value of a dollar is 1.0, the value of a quarter is 0.25, 
	 * and the value of a dime is 0.1.
	 * 
	 * The returned value should be rounded to 2 decimal places.
	 * @return total value rounded to 2 decimal places
	 */
	public double calculateValue() {
		
		//TODO Add your code here
		return 0.0;
	}

	/**
	 * Given a particular itemCost, calculates the difference between this Payment
	 * amount and that cost. This is known as the "change" from the purchase, such
	 * that change + itemCost == this.calculateValue().
	 * 
	 * The change should be returned as a Payment, i.e. an object containing an
	 * integer amount of dollars, quarters, and dimes.
	 * 
	 * You can assume that the change can always be expressed as a sum of dollars,
	 * quarters, and dimes, or a sum of dollars and quarters, or a sum of dollars.
	 * That is, you might have $1.50 in change (1 dollar, 2 quarters) or $1.60 (1
	 * dollar, 2 quarters, 1 dime). You don't have to worry about making change for
	 * $1.40, which could only be expressed as 1 dollar, 4 dimes.
	 * 
	 * Throws an Exception if the given itemCost is greater than this
	 * Payment amount, i.e. itemCost > this.calculateValue(). Exception should 
	 * contain a message in a similar format to: 
	 * $2.30 is too expensive.  You only have $2.20.
	 * 
	 * @param itemCost for particular item
	 * @return A Payment containing an integer amount of dollars, quarters, and dimes
	 * @throws Exception if the given itemCost is greater than this Payment amount
	 */
	public Payment makeChangeForPurchase(double itemCost) throws Exception {
		
		//TODO Add your code here
		return null;
	}
}