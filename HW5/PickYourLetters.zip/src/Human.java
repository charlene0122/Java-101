import java.util.Scanner;

/**
 * Represents a human player.
 *
 */
public class Human {
	
	/**
	 * Human player's hand.
	 */
	String[] handCards;
	
	/**
	 * Access to main pile and discard pile.
	 */
	Cards cards;
	
	/**
	 * Creates a human player.
	 * Gives access to the main pile and discard pile via given instance of Cards class.
	 * @param cards for access to main pile and discard pile
	 */
	public Human(Cards cards) {
		this.cards = cards;
	}
	
	/**
	 * Sets human player's hand.
	 * @param handCards to set
	 */
	public void setHandCards(String[] handCards) {
		
		//TODO Add your code here
	}
	
	/**
	 * Gets human player's hand.
	 * @return human player's hand
	 */
	public String[] getHandCards() {
		
		//TODO Add your code here
	}
	
	/**
	 * Controls the game play for the human.
	 * @param scanner to use for user input
	 */
	public void play(Scanner scanner) {
		
		//TODO Add your code here
	}
	
	/**
	 * Displays (prints) the given msg and uses the given scanner to get user input 
	 * of a response.
	 * The expected response is yes/y or no/n.
	 * Prompts again if the response is invalid.
	 * @param msg to be displayed
	 * @return true if user answers yes/y, or false if user answers no/n
	 */
	public boolean askYesOrNo(String msg, Scanner scanner) {
		
		//TODO Add your code here
	}
	
	/**
	 * Asks the index of letter the user wants to replace.
	 * Prompts again if the input index is invalid or out of index range.
	 * @param length the valid index range should be in 0 to given length
	 * @param scanner to be used for user input
	 * @return the index of the letter to be replaced
	 */
	public int askForTheLetterToBeReplaced(int length, Scanner scanner) {
	    
		//TODO Add your code here
	}
}
