

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PaymentTest {

	@Test
	void testCalculateValue() {
		//create payment
		Payment myMoney = new Payment(2, 1, 1);
		assertEquals(2.35, myMoney.calculateValue(), 0.000001);
		
		
		//create another payment
		myMoney = new Payment(5, 0, 0);
		assertEquals(5.00, myMoney.calculateValue(), 0.000001);
		
		
		//TODO Add 2 more test cases here
		//Hint:
		//- Consider a test case for a payment of 1 dime
		//- Consider a test case for a payment of 0 dollars, quarters, and dimes
	}
		
	
	@Test
	void testMakeChangeForPurchase() {
		//create payment
		Payment myMoney = new Payment(2, 1, 1);
		
		//try to get change
		try {
			myMoney = myMoney.makeChangeForPurchase(1.25);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		//check value of change
		assertEquals(1.10, myMoney.calculateValue(), 0.000001);
		
		
		//TODO Add 2 more test cases here
		//Hint:
		//- Consider a test case for making change for a purchase of 1.10
		//- Consider a test case for making change for a purchase of 0.01
						
	}

}
